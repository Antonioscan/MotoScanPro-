function startApp() {
    alert('Demo MotoScanPro in caricamento...');
}

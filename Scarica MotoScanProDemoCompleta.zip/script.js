document.addEventListener("DOMContentLoaded", function () {
  const splash = document.getElementById("splash-screen");
  setTimeout(() => splash.style.display = "none", 2000);

  document.getElementById("snapBtn").addEventListener("click", function () {
    const fileInput = document.getElementById("fileInput");
    const result = document.getElementById("result");

    if (!fileInput.files || fileInput.files.length === 0) {
      result.textContent = "Nessun file selezionato.";
      return;
    }

    result.textContent = "Analisi immagine in corso...";
    setTimeout(() => {
      result.innerHTML = "<strong>Pinza freno radiale rilevata – Ducati</strong>";
    }, 1500);
  });
});
